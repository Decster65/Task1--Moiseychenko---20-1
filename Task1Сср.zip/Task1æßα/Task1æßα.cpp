﻿// Task1Сср.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Rus");
	//1 Задача//
	try
	{
		cout << "Задача #1" << endl;
		double t, l;
		cout << "Введите значение переменной t " << endl;
		cin >> t;
		cout << "Введите значение переменной l " << endl;
		cin >> l;
		cout << "R =" << 3 * pow(t, 2) + 3 * pow(l, 5) + 4.9 << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause")
		;
	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}
	//2 Задача //
	try
	{
		cout << "Задача #2" << endl;
		double p, y;
		cout << "Введите значение переменной p " << endl;
		cin >> p;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "K =" << log10(pow(p, 2) + pow(y, 3)) + exp(p) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}
	// 3 Задача //
	try
	{
		cout << "Задача #3" << endl;
		double n, y;
		cout << "Введите значение переменной n " << endl;
		cin >> n;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "G =" <<n*(y+3.5)+sqrt(y)  << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 4 Задача //
	try
	{
		cout << "Задача #4" << endl;
		double a,t;
		cout << "Введите значение переменной a " << endl;
		cin >> a;
		cout << "Введите значение переменной t " << endl;
		cin >> t;
		cout << "D =" <<9.8*pow(a,2)+5.52*pow(cos(t), 5) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 5 Задача //
	try
	{
		cout << "Задача #5" << endl;
		double x;
		cout << "Введите значение переменной x " << endl;
		cin >> x;
		cout << "L =" <<1.51*cos(pow(x,2))+2*pow(x,3)<< endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 6 Задача //
	try
	{
		cout << "Задача #6" << endl;
		double y,x;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;

		cout << "M =" <<cos(2*y)+3.6*exp(x)  << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 7 Задача //
	try
	{
		cout << "Задача #7" << endl;
		double m;
		cout << "Введите значение переменной m " << endl;
		cin >> m;

		cout << "N =" << pow(m,2)+2.8*fabs(m)+0.55 << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 8 Задача //
	try
	{
		cout << "Задача #8" << endl;
		double y;
		cout << "Введите значение переменной y " << endl;
		cin >> y;

		cout << "T ="<<sqrt(fabs(6*pow(y,2)-0.1*y+4))  << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 9 Задача //
	try
	{
		cout << "Задача #9" << endl;
		double y,x;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;

		cout << "V =" << log10(y+0.95)+sin(pow(x,4)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 10 Задача //
	try
	{
		cout << "Задача #10" << endl;
		double y, k,x;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной k " << endl;
		cin >> k;
		cout << "Введите значение переменной x " << endl;
		cin >> x;

		cout << "U =" << exp(y)+7.355*pow(k,2)+pow(sin(y),2) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 11 Задача //
	try
	{
		cout << "Задача #10" << endl;
		double y,  x;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;

		cout << "S =" <<9.756*pow(y,7)+2*tan(x)<< endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 11 Задача //
	try
	{
		cout << "Задача #11" << endl;
		double y, x;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;

		cout << "S =" << 9.756 * pow(y, 7) + 2 * tan(x) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 12 Задача //
	try
	{
		cout << "Задача #12" << endl;
		double t, x;
		cout << "Введите значение переменной t " << endl;
		cin >> t;
		cout << "Введите значение переменной x " << endl;
		cin >> x;

		cout << "K =" << 7*pow(t,2)+3*sin(pow(x,3))+9.2<< endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 13 Задача //
	try
	{
		cout << "Задача #13" << endl;
		double y;
		cout << "Введите значение переменной y " << endl;
		cin >> y;

		cout << "E =" << sqrt(fabs(3*pow(y,2)+0.5*y+4)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 14 Задача //
	try
	{
		cout << "Задача #14" << endl;
		double y,x;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;

		cout << "R =" << fabs(sqrt(pow(sin(y),2) + 6.835) + exp(x)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 15 Задача //
	try
	{
		cout << "Задача #15" << endl;
		double y;
		cout << "Введите значение переменной y " << endl;
		cin >> y;

		cout << "H =" << sin(pow(y,2)-2.8*y+sqrt(fabs(y))) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 16 Задача //
	try
	{
		cout << "Задача #16" << endl;
		double y;
		cout << "Введите значение переменной y " << endl;
		cin >> y;

		cout << "S =" << sqrt(cos(4*pow(y,2))+7.151) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 17 Задача //
	try
	{
		cout << "Задача #17" << endl;
		double y;
		cout << "Введите значение переменной y " << endl;
		cin >> y;

		cout << "N =" << 3*pow(y,2)+sqrt(y+1) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 18 Задача //
	try
	{
		cout << "Задача #18" << endl;
		double y;
		cout << "Введите значение переменной y " << endl;
		cin >> y;

		cout << "Z =" << 3 * pow(y,2)+sqrt(pow(y,3)+1) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 19 Задача //
	try
	{
		cout << "Задача #19" << endl;
		double n,g,y;
		cout << "Введите значение переменной n " << endl;
		cin >> n;
		cout << "Введите значение переменной g " << endl;
		cin >> g;
		cout << "Введите значение переменной y " << endl;
		cin >> y;

		cout << "P =" << n*sqrt(pow(y,3)+1.09*g) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 20 Задача //
	try
	{
		cout << "Задача #20" << endl;
		double k,x, y;
		cout << "Введите значение переменной k " << endl;
		cin >> k;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;

		cout << "U =" << exp(k+y)+tan(x)*sqrt(y) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 21 Задача //
	try
	{
		cout << "Задача #21" << endl;
		double h, y;
		cout << "Введите значение переменной k " << endl;
		cin >> h;
		cout << "Введите значение переменной y " << endl;
		cin >> y;


		cout << "P =" << exp(y+5.5)+9.1*pow(h,3) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 22 Задача //
	try
	{
		cout << "Задача #22" << endl;
		double u, y,x;
		cout << "Введите значение переменной u " << endl;
		cin >> u;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;


		cout << "T =" << sin(2*u)*log10(2*pow(y,2)+sqrt(x)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 23 Задача //
	try
	{
		cout << "Задача #23" << endl;
		double f, y;
		cout << "Введите значение переменной f " << endl;
		cin >> f;
		cout << "Введите значение переменной y " << endl;
		cin >> y;


		cout << "G =" << exp(2*y)+sin(f) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}
	// 24 Задача //
	try
	{
		cout << "Задача #24" << endl;
		double  y;
		cout << "Введите значение переменной y " << endl;
		cin >> y;


		cout << "F =" << 2*sin(0.214*pow(y,5)+1) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 25 Задача //
	try
	{
		cout << "Задача #25" << endl;
		double  y,f;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной f " << endl;
		cin >> f;


		cout << "G =" << exp(2*y)+sin(pow(f,2)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 26 Задача //
	try
	{
		cout << "Задача #26" << endl;
		double  p;
		cout << "Введите значение переменной y " << endl;
		cin >> p;



		cout << "Z =" << sin(pow(pow(p,3)+0.4, 3)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 27 Задача //
	try
	{
		cout << "Задача #27" << endl;
		double  y,x;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной x " << endl;
		cin >> x;



		cout << "W =" <<1.03*y+exp(2*y)+tan(fabs(x))  << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 28 Задача //
	try
	{
		cout << "Задача #28" << endl;
		double  y, h;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной h " << endl;
		cin >> h;



		cout << "T =" << exp(y + h) + sqrt(fabs(6.4 * y)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 29 Задача //
	try
	{
		cout << "Задача #29" << endl;
		double  y;
		cout << "Введите значение переменной y " << endl;
		cin >> y;




		cout << "N =" << 3*pow(y,2)+sqrt(fabs(y+1)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}

	// 30 Задача //
	try
	{
		cout << "Задача #30" << endl;
		double  y,r;
		cout << "Введите значение переменной y " << endl;
		cin >> y;
		cout << "Введите значение переменной r " << endl;
		cin >> r;




		cout << "W =" << exp(y+r)+7.2*sin(r) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ошибка входных данных" << endl;
	}

	system("pause");

	void clear(); {
		std::cout << "\x1B[2J\x1B[H";
	}
}

